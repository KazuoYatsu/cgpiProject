package primitivos;

import javafx.scene.paint.Color;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.io.Serializable;

@XmlRootElement(name = "Retangulo")
public class Retangulo implements Serializable {
    private Ponto diagonalMin;
    private Ponto diagonalMax;
    private Color cor;

    public Retangulo() {
    }

    public Retangulo(Ponto diagonalMin, Ponto diagonalMax, Color cor) {
        this.diagonalMin = diagonalMin;
        this.diagonalMax = diagonalMax;
        this.setCor(cor);
    }

    @XmlElement(name = "Ponto")
    public Ponto getDiagonalMin() {
        return diagonalMin;
    }


    @XmlElement(name = "Ponto")
    public Ponto getDiagonalMax() {
        return diagonalMax;
    }

    // Esse SET s� deve ser utilizado pela api de leitura de xml
    public void setDiagonalMax(Ponto diagonalMax) {
        if (this.diagonalMax == null)
            this.diagonalMax = diagonalMax;
        else
            this.diagonalMin = diagonalMax;
    }

    @XmlTransient
    public Color getCor() {
        return cor;
    }

    public void setCor(Color cor) {
        this.cor = cor;
    }

    @XmlElement(name = "Cor")
    public Cor getCustomColor() {
        return new Cor(this.cor.getRed(), this.cor.getGreen(), this.cor.getBlue());
    }

    public void setCustomColor(Cor cor) {
        this.cor = cor.toColor();
    }
}
