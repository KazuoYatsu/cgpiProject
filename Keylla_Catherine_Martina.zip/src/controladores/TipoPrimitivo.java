package controladores;

public enum TipoPrimitivo {
    RETA, RETANGULO, CIRCULO, POLIGONO, LINHA_POLIGONAL
}
