package utils;

public interface AlertaCallback {
    void alertaCallbak();
}
