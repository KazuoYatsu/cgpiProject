#Projeto CGPI

## Integrantes
- Keylla
- Martina
- Catherine
- Otavio

## Desenhos Implementadas
- Ponto
- Reta
- Circulo
- Curva do Dragão
- Retas e Circulos

## Features
- Seleção de Cor
- Seleção do Tamanho do Ponto