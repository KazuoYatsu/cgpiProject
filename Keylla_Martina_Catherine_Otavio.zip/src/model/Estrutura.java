package model;

public class Estrutura {
    private Object formaGeometrica;
    private boolean visivel;

    public Object getFormaGeometrica() {
        return formaGeometrica;
    }

    public void setFormaGeometrica(Object formaGeometrica) {
        this.formaGeometrica = formaGeometrica;
    }

    public boolean isVisivel() {
        return visivel;
    }

    public void setVisivel(boolean visivel) {
        this.visivel = visivel;
    }
}
