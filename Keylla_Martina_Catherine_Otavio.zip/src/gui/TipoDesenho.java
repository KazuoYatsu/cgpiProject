package gui;

public enum TipoDesenho { //define os tipos de desenho
	RETA,
	CIRCULO,
	PONTO,
	CURVA_DO_DRAGAO,
	RETAS_CIRCULOS,
}
